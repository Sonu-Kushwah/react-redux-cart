import logo from './logo.svg';
import './App.css';
import Header from './component/Header';
import Home from "./component/Home"
import CartDaitels from './component/CartDaitels';
import {Routes,Route} from 'react-router-dom'

function App() {
  return (
   <>
   <Header/>
   <Routes>
   <Route path='/' element={<Home />} />
   <Route path='/Cart/:id' element={<CartDaitels />} />
   </Routes>
   </>
  );
}

export default App;
